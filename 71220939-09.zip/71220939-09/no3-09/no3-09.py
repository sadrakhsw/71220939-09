print("====Kata Unik pada Berita====")
handle = open("artikel.txt")
baris = handle.read().split()
seting_huruf = set()
kata_unik = []
for i in baris:
    if i not in seting_huruf:
        kata_unik.append(i)
        seting_huruf.add(i)
print(kata_unik)

