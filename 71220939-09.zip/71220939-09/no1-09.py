nilai_angka = [13,10,18,3,22,1]
nilai_angka.sort(reverse=True)

for i in range(3):
    print("nilai terbaik ke {} = {}" .format(i+1,nilai_angka[i]))