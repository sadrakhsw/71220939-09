sebuah_list = []
keterangan = True
masuk = 0

print("masukkan nilai angka, dan done untuk mengakhirinya")
while keterangan == True:
    masuk = input("masukkan input: ")

    if masuk != "done":
        masuk = int(masuk)
        sebuah_list.append(masuk)
    else:
        break

print("Nilai Max : {}" .format(max(sebuah_list)))
print("Nilai Min : {}" .format(min(sebuah_list)))